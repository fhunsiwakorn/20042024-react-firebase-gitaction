import BaseLayout from "./BaseLayout";
function App() {
  return (
    <div>
      <BaseLayout />
    </div>
  );
}

export default App;
