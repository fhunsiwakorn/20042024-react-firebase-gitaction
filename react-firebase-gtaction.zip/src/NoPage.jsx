import React, { Component } from "react";

export default class NoPage extends Component {
  render() {
    return (
      <div>
        <div align="center">
          <h1>Error Content</h1>
        </div>
      </div>
    );
  }
}
