const exports = {};
exports.API_URL = "https://iotapi.thaionzon.com/getZipcode";
exports.options = {
  headers: {
    "Content-type": "application/json",
    Authorization: "k4pGvhg7GNKYznhW",
  },
};
export default exports;
